import React from 'react';

function Footer() {
	return (
		<div
			style={{
				height: '100px',
				display: 'flex',
				// flexDirection: 'column',
				alignItems: 'center',
				justifyContent: 'center',
				fontSize: '1rem',
				// backgroundColor: '#23272a',
			}}
		>
			<p> 김동휘 & 김형욱 & 이다원 </p>
		</div>
	);
}

export default Footer;
