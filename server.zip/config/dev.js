module.exports = {
	mongoURI:
		'mongodb+srv://ehdgnl5249:kk5249@nodewebproj.ex5jz.mongodb.net/node?retryWrites=true&w=majority',
	KAKAO_ID: '06fa834ccf8689191fbc7cac18d483f2',
	FACEBOOK_ID: '398772811259827',
	FACEBOOK_SECRET: '87131235d9d3e5914fc25352dafd70b4',
	NAVER_ID: 'GZF1U4DVtWaB_RwW_lZz',
	NAVER_CLIENT: 'qd8NMj_GYs',
};
